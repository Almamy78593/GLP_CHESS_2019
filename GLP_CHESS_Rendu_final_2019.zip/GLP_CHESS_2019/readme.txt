XiangQi, le jeu d'�chec interractif.
Projet de GLP L2: CHESS

Ce logiciel a �t� d�velopp� par:
CHENET Dorian
CAMARA Almamy
CHOLLET Alexis

Ce programme peut �tre lanc� � partir du logiciel Eclipse.
La fonction main() se trouve dans la classe Main (package test.io).
Vous pouvez aussi retrouver les tests unitaires dans ce m�me package.

L'utilisation du logiciel s'effectue enti�rement � partir de l'interface graphique d�s
que le jeu est lanc�.
Les fichiers txt contenant les diff�rents param�tres du jeu sont aussi pr�sents dans
le package test.io.
Les diff�rentes textures du jeu sont r�parties dans diff�rents emplacements:
-texture_menu
-image
-package textures

L'utilisation de ce logiciel ne n�cessite pas de logiciel tiers autre que Eclipse ni
d'add-ons particuliers.