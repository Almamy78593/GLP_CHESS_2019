package test.io;

import graphic.GraphicsMainMenu;

public class Main {

	public static void main(String[] args) {
		new GraphicsMainMenu();
	}

}
